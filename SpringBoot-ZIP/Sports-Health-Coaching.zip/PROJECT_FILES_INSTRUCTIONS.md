## Read-only Files
The following files are marked read-only. You cannot edit these files
in the editor; however, it is possible from the terminal. You must not
modify or delete these files because doing so results in a zero score.

* src/test/java/com/hackerrank/whc/controller/CoachControllerTest.java
* src/test/java/com/hackerrank/whc/controller/CustomerControllerTest.java
* src/test/resources/application.yml